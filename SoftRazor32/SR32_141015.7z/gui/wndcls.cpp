#include "../sr_pch.h"
#include "../udis86/udisconfig.h"

static PCLASS_TABLE ClassTableHeader = NULL;
static PCLASS_TABLE LastClassTable = NULL;

BOOL AddClassTable(HWND hWnd, PVOID pClass)
{
  if (!pClass) return FALSE;

  PCLASS_TABLE ptmp = (PCLASS_TABLE)malloc(sizeof(CLASS_TABLE));

  if (!ptmp) return FALSE;

  ptmp->hWindow = hWnd;
  ptmp->pClass = pClass;
  ptmp->Next = NULL;

  if (LastClassTable)
  {
    LastClassTable->Next = ptmp;
    LastClassTable = ptmp;
  }
  else
  {
    ClassTableHeader = ptmp;
    LastClassTable = ptmp;
  }

  return TRUE;
}

PVOID GetClassPointer(HWND hWnd)
{
  PCLASS_TABLE PCT = ClassTableHeader;

  while (PCT)
  {
    if (PCT->hWindow == hWnd) return PCT->pClass;
    PCT = PCT->Next;
  }

  return NULL;
}

BOOL DelClassTable(HWND hWnd)
{
  PCLASS_TABLE PCT = ClassTableHeader;
  PCLASS_TABLE PCTL = ClassTableHeader; // 0

  if (!PCT) return FALSE;

  if (PCT->hWindow == hWnd) //Header
  {
    /* ������ָ����ڱ�ͷ */
    if (LastClassTable == ClassTableHeader)
    {
      ClassTableHeader = ClassTableHeader->Next;
      LastClassTable = LastClassTable->Next;
    }
    else
    {
      ClassTableHeader = ClassTableHeader->Next;
    }

    free(PCT);
    return TRUE;
  }

  PCT = PCT->Next;  // ��һ���ṹ 1

  while (PCT)
  {
    if (PCT->hWindow == hWnd)
    {
      PCTL->Next = PCT->Next;

      if (LastClassTable == PCT) //if LastClassTable == PCT , PCT->Next == NULL
        LastClassTable = PCTL;

      free(PCT);
      return TRUE;
    }

    PCTL = PCT;
    PCT = PCT->Next;
  }

  return FALSE;
}

MDIForm::~MDIForm()
{
  if (this->m_hWnd)
  {
    DestroyWindow(this->m_hWnd);
    this->m_hWnd = NULL;
  }
}

COLORREF QueryForeColor(short stype)
{
  switch (stype)
  {
  case UDCA_Inst: return DCF_Inst;
  case UDCA_StackOp: return DCF_StackOp;
  case UDCA_FMSOp: return DCF_FMSOp;
  case UDCA_CJump: return DCF_CJump;
  case UDCA_Jump: return DCF_Jump;
  case UDCA_Call: return DCF_Call;
  case UDCA_Ret: return DCF_Ret;
  case UDCA_PrivInst: return DCF_PrivInst;
  case UDCA_Prefix: return DCF_Prefix;
  case UDCA_DefClr: return DCF_DefClr;
  case UDCA_Int: return DCF_Int;
  case UDCA_Data: return DCF_Data;
  case UDCA_Text: return DCF_Text;
  case UDCA_Symbol: return DCF_Symbol;
  case UDCA_Error: return DCF_Error;
  case UDCA_GPRs: return DCF_GPRs;
  case UDCA_FSRs: return DCF_FSRs;
  case UDCA_SSRs: return DCF_SSRs;
  case UDCA_MStack: return DCF_MStack;
  case UDCA_MOther: return DCF_MOther;
  case UDCA_IMM: return DCF_IMM;
  case UDCA_IMMAddr: return DCF_IMMAddr;
  case UDCA_Change: return DCF_Change;
  default: return DCF_DefClr;
  };
}

COLORREF QueryBackColor(short stype)
{
  switch (stype)
  {
  case UDCA_Inst: return DCB_Inst;
  case UDCA_StackOp: return DCB_StackOp;
  case UDCA_FMSOp: return DCB_FMSOp;
  case UDCA_CJump: return DCB_CJump;
  case UDCA_Jump: return DCB_Jump;
  case UDCA_Call: return DCB_Call;
  case UDCA_Ret: return DCB_Ret;
  case UDCA_PrivInst: return DCB_PrivInst;
  case UDCA_Prefix: return DCB_Prefix;
  case UDCA_DefClr: return DCB_DefClr;
  case UDCA_Int: return DCB_Int;
  case UDCA_Data: return DCB_Data;
  case UDCA_Text: return DCB_Text;
  case UDCA_Symbol: return DCB_Symbol;
  case UDCA_Error: return DCB_Error;
  case UDCA_GPRs: return DCB_GPRs;
  case UDCA_FSRs: return DCB_FSRs;
  case UDCA_SSRs: return DCB_SSRs;
  case UDCA_MStack: return DCB_MStack;
  case UDCA_MOther: return DCB_MOther;
  case UDCA_IMM: return DCB_IMM;
  case UDCA_IMMAddr: return DCB_IMMAddr;
  case UDCA_Change: return DCB_Change;
  default: return DCB_DefClr;
  };
}

int DrawCasmW(HDC hdc, PWCHAR lpcasm, size_t bufmax, LONG wspace, LPCRECT lprc, UINT format)
{
  COLORREF fc = GetTextColor(hdc);
  COLORREF bc = GetBkColor(hdc);
  COLORREF cbc;
  PWCHAR pwcs = lpcasm;
  int dcount = 0;
  size_t i;
  size_t wlen;
  SIZE wsize;
  RECT rect = *lprc;

  if (!pwcs) return 0;

  for (i = 0; i < bufmax; i++)
  {
    if (pwcs[i] == 0) break;
    SetTextColor(hdc, QueryForeColor(pwcs[i]));  //��ȡ������ǰ��ɫ
    cbc = QueryBackColor(pwcs[i]);

    if ((cbc & 0x00FFFFFF) == 0x00FFFFFF)
      SetBkMode(hdc, TRANSPARENT);//���ñ�����ʽ
    else
    {
      SetBkMode(hdc, OPAQUE);//���ñ�����ʽ
      SetBkColor(hdc, cbc);  //���ñ���ɫ
    }

    i++;    //�ƶ��������ַ���ʼ
    if (!(wlen = wcslen(&pwcs[i]))) break;  //ȡ�ַ�����
    if (i + wlen >= bufmax) break;  //�ж��Ƿ񳬳����ֵ
    GetTextExtentPointW(hdc, &pwcs[i], wlen, &wsize);
    rect.right = rect.left + wsize.cx /*+ wspace*/;
    if (rect.right > lprc->right) rect.right = lprc->right;
    DrawTextW(hdc, &pwcs[i], wlen, &rect, format);
    dcount++;

    if (rect.right >= lprc->right) break;
    rect.left = rect.right;
    i += wlen;
  }
  SetTextColor(hdc, fc);
  SetBkColor(hdc, bc);
  return dcount;
}

HWND MDIForm::GetMainhWnd()
{
  return this->m_hWnd;
}

BOOL MDIForm::SetTop()
{
  return SetWindowPos(this->m_hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
}

BOOL MDIForm::DestroyForm()
{
  BOOL ret;

  if (!this->m_hWnd) return FALSE;
  ret = DestroyWindow(this->m_hWnd);
  this->m_hWnd = NULL;
  return ret;
}