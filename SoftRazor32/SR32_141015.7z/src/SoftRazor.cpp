#include "../sr_pch.h"
#include "../resource.h"

MainForm  * mf = NULL;

UINT WINAPI DbgWndThread(PVOID Param)
{
  BOOL gmret;
  MSG dwmsg;

  SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
  DllEntry(DllBaseAddr, DLL_THREAD_ATTACH, 0);
  InitCommonControls();

  if (!mf)
  {
    mf = MainForm::GetInstance(DllBaseAddr);
    if (!mf) return 0;
  }

  mf->CreateForm(WN_MAIN, WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_MAXIMIZE, DllBaseAddr);
  if (mf->GetMainWindow() == NULL) return 0;

  SR_SetHandler();

  while ((gmret = GetMessage(&dwmsg, 0, 0, 0)) != 0)
  {
    if (gmret == -1)
      return -1;

    if (mf->GetDbgState() != DS_Idle)
    {
      switch (dwmsg.message)
      {
      /* ����������Ϣ */
      case WM_KEYDOWN:
      case WM_KEYUP:
      case WM_LBUTTONDOWN:
      case WM_LBUTTONUP:
      case WM_RBUTTONDOWN:
      case WM_RBUTTONUP:
      case WM_CLOSE:
        continue;
      default:
        break;
      }
    }
    TranslateMessage(&dwmsg);
    DispatchMessage(&dwmsg);
  }

  SR_RemoveHandler();
  DllEntry(DllBaseAddr, DLL_THREAD_DETACH, 0);
  return 1;
}

BOOL WINAPI LaunchDebugger(ULONG LaunchParam)
{
  if (ht_main) return FALSE;
  ht_main = _beginthreadex(0, 4194304, &DbgWndThread, NULL, 0, &tid_main);
  return (ht_main == 0 || ht_main == -1) ? FALSE : TRUE;
}

BOOL WINAPI TerminateDebugger(BOOL blEnforce)
{
  if (ht_main == 0 || ht_main == -1) return FALSE;
  if (mf) mf->Release();
  _endthreadex(ht_main);
  ht_main = NULL;
  tid_main = 0;
  return TRUE;
}

