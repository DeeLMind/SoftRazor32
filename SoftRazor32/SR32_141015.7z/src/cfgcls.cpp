#include "../sr_pch.h"

GlobalConfig::GlobalConfig() : fdeval(0), ldeval(0)
{
  UINT i,los = 0;
  TCHAR stmp[MAX_PATH];

  GetModuleFileName(DllBaseAddr,stmp,MAX_PATH);

  for (i = 0; i < MAX_PATH;i++)
  {
    if (!stmp[i]) break;
    if (stmp[i] == _T('\\')) los = i;
  }

  stmp[los] = 0;
  _stprintf_s(WorkDir, MAX_PATH, _T("%s\\"), stmp);
  _stprintf_s(CfgFile, MAX_PATH, _T("%s\\srdbg.ini"), stmp);
}

void GlobalConfig::LoadAllConfig()
{
  BOOL rval = TRUE;
  HANDLE hFile;
  DWORD dwtmp;
  TCHAR stmp[MAX_PATH];

  hFile = CreateFile(CfgFile, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
    NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

  if (hFile == INVALID_HANDLE_VALUE)
  {
    ResetAllConfig();
    SaveAllConfig();
  }
  else
    CloseHandle(hFile);

  dwtmp = GetPrivateProfileString(_T("Base"), _T("FirstException"), _T("00000000"), stmp, MAX_PATH, CfgFile);
  if (_stscanf_s(stmp, HEXFORMAT, &dwtmp) == 1)
    fdeval = dwtmp;
  else
    fdeval = 0;

  dwtmp = GetPrivateProfileString(_T("Base"), _T("LastException"), _T("00000000"), stmp, MAX_PATH, CfgFile);
  if (_stscanf_s(stmp, HEXFORMAT, &dwtmp) == 1)
    ldeval = dwtmp;
  else
    ldeval = 0;
}

BOOL GlobalConfig::SaveAllConfig()
{
  BOOL rval = TRUE;
  TCHAR stmp[MAX_PATH];

  _stprintf_s(stmp, MAX_PATH, HEXFORMAT, fdeval);
  if (!WritePrivateProfileString(_T("Base"), _T("FirstException"), stmp, CfgFile))
    rval = FALSE;

  _stprintf_s(stmp, MAX_PATH, HEXFORMAT, ldeval);
  if (!WritePrivateProfileString(_T("Base"), _T("LastException"), stmp, CfgFile))
    rval = FALSE;

  return rval;
}

void GlobalConfig::ResetAllConfig()
{
  fdeval = 0;
  ldeval = 0xFFFFF;
}

LPCTCH GlobalConfig::GetWorkDirectory()
{
  return WorkDir;
}