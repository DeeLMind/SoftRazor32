#pragma once

#ifndef _SR_INC_COMMON_H_
#include "common.h"
#endif

//Global Define

#define MY_MAGIC            0x3940A512
#define VB_MAGIC            0x21354256

#define NVE_TEXT            _T("����: Soft Razor �޷��ڵ�ǰϵͳ������!\n\n���ϵͳ�汾(NT�汾):\n�ͻ���: Win XP        �����: WinServer 2003")
#define ERR_TITLE           _T("����")
#define DEF_VCHILD          WS_CHILD | WS_VISIBLE
#define DEF_WINDOW          WS_CHILD | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX
#define LV_STYLE            DEF_VCHILD | LVS_REPORT
#define DEF_BTNSTYLE        DEF_VCHILD | BS_USERBUTTON
#define TV_STYLE            DEF_VCHILD | TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES | TVS_SHOWSELALWAYS
#define MDI_STYLE           DEF_WINDOW | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN

#define VBPC_NULLITEM       0
#define VBPC_STRUCT         1
#define VBPC_OBJECT         2
#define VBPC_ROOTFORM       3
#define VBPC_FORM           4
#define VBPC_FRMCTL         5
#define VBPC_BAS            6
#define VBPC_CLS            7
#define VBPC_UC             8
#define VBPC_UCCTL          9

#define VBII_NULLITEM       0
#define VBII_VBHDR          1
#define VBII_PRJI           2
#define VBII_COMD           3
#define VBII_COMI           4
#define VBII_OBJTAB         5
#define VBII_OBJS           6

#define DefWidth            76

#define HEXFORMAT           _T("%08X")
#define FT_TAH              _T("Tahoma")
#define FT_VER              _T("Verdana")
#define FT_FIX              _T("Fixedsys")
#define T_NTDLL             _T("ntdll.dll")

#define T_SEPARATOR         _T("|")
#define T_REFRESH           _T("ˢ��")
#define T_VIEW              _T("�鿴")
#define T_ASK               _T("ѯ��")
#define T_IGNORE            _T("*����*")
#define T_NULL              _T("\0\0")
#define T_UNKN1             _T("?")
#define T_UNKN2             _T("??")
#define T_UNKN4             _T("????")
#define T_UNKN8             _T("????????")
#define T_UNKNOWN           _T("δ֪")
#define T_OTHER             _T("����")
#define T_COMMIT            _T("�ѷ���")
#define T_RESERVE           _T("����")

#define T_FILEHEADER        _T("*[Header]*")

#define T_M_IMAGE           _T("{ӳ��}")
#define T_M_MAPPED          _T("[ӳ��]")
#define T_M_PRIVATE         _T("(˽��)")

#define T_P_NOACCESS        _T("��ֹ")
#define T_P_READONLY        _T("ֻ��")
#define T_P_READWRITE       _T("��д")
#define T_P_WRITECOPY       _T("������")
#define T_P_EXECUTE         _T("��ִ��")
#define T_P_EXECUTE_R       _T("ֻ��ִ��")
#define T_P_EXECUTE_RW      _T("��дִ��")
#define T_P_EXECUTE_WC      _T("����ִ��")
#define T_P_GUARD           _T("�����쳣")
#define T_P_NOCACHE         _T("��ֹ����")
#define T_P_WRITECOMBINE    _T("���д��")

#define T_H_DEFAULT         _T("����Ĭ�϶�")
#define T_H_SHARED          _T("������")

#define T_HB_FIXED          _T("�ڴ�鲻���ƶ�")
#define T_HB_FREE           _T("�ڴ��δʹ��")
#define T_HB_MOVEABLE       _T("�ڴ����ƶ�")

#define T_TP_AN             _T("���ڱ�׼")
#define T_TP_BN             _T("���ڱ�׼")
#define T_TP_HE             _T("���")
#define T_TP_IDLE           _T("����")
#define T_TP_LE             _T("���")
#define T_TP_NM             _T("��׼")
#define T_TP_TC             _T("ʵʱ")

#define T_TS_RUN            _T("��������")
#define T_TS_SP             _T("�ѹ���")
#define T_TS_WAIT           _T("�ȴ�����")
#define T_TS_TIM            _T("����ֹ")

#define T_DBGS_BUSY         _T("SoftRazor æµ��,��ȴ����̽���...")

/* Window Class */
#define WC_MAIN             _T("sr_window")
#define WC_APIHOOK          _T("sr_apihook")
#define WC_MODULE           _T("sr_module")
#define WC_MEMORY           _T("sr_memory")
#define WC_HEAP             _T("sr_heap")
#define WC_THREAD           _T("sr_thread")
#define WC_DISASM           _T("sr_disasm")
#define WC_VB               _T("sr_vbstruct")
#define WC_PCPROC           _T("sr_pcodeproc")


/* Class Name */
#define CN_MDI              _T("MDIClient")
#define CN_STATIC           _T("Static")
#define CN_EDIT             _T("Edit")
#define CN_BUTTON           _T("Button")

/* Window Name */
#define WN_MAIN             _T("SoftRazor Win32")
#define WN_MODULE           _T("ģ���б�")
#define WN_MEMORY           _T("�ڴ�ӳ��")
#define WN_HEAP             _T("���̶�")
#define WN_THREAD           _T("�߳��б�")
#define WN_DISASM           _T("�����")
#define WN_VB               _T("VB�ṹ")
#define WN_PCPROC           _T("P-Code ����")

/* ListView Name */
#define LN_MODULE           _T("LV_Process")
#define LN_SECTION          _T("LV_Section")
#define LN_MEMORY           _T("LV_Memory")
#define LN_HEAP             _T("LV_Heap")
#define LN_THREAD           _T("LV_Thread")
#define LN_VBLIST           _T("LV_VbStruct")

/* TreeView Name */
#define TN_VBTREE           _T("TV_VbStruct")

#define SC_EX               _T("��ִ��")
#define SC_OR               _T("ֻ��")
#define SC_RW               _T("��д")
#define SC_SH               _T("����")
#define SC_DC               _T("�ɶ���")
#define SC_NP               _T("����ҳ")
#define SC_RT               _T("�ض�λ")
#define SC_ID               _T("�ѳ�ʼ������")
#define SC_UD               _T("δ��ʼ������")
#define SC_CD               _T("����COMDAT")

