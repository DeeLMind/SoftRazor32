#include "../sr_pch.h"

WCHAR   REX_DebugInfoDatabase::gpath[MAX_PATH] = { 0 };

REX_DebugInfoDatabase::REX_DebugInfoDatabase() : BindToFile(FALSE), hFile(INVALID_HANDLE_VALUE),
HMM(HMMF_ENABLE_LFH | HMMF_ENABLE_COMPACT, 4194304), ModuleList(NULL), DS(NULL), DB(NULL), SM(NULL)
{
  fpath[0] = 0;
}

REX_DebugInfoDatabase::~REX_DebugInfoDatabase()
{
  if (hFile != INVALID_HANDLE_VALUE) CloseHandle(hFile);
  HMM.hdestroy();
}

void REX_DebugInfoDatabase::SetGlobalWorkDir(PWCHAR pgwdir)
{
  wcscpy_s(gpath, MAX_PATH, pgwdir);
}

BOOL REX_DebugInfoDatabase::CreateDebugInfoDatabase(DWORD cFlag, PWCHAR mName)
{
  if (BindToFile) return FALSE;
  if (hFile != INVALID_HANDLE_VALUE) CloseHandle(hFile);
  swprintf_s(fpath, MAX_PATH, L"%s\\%s.csdb", gpath, mName);

  hFile = CreateFile(fpath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_NEW,
    FILE_ATTRIBUTE_NORMAL, NULL);           //�½��ļ�,���������ʧ��

  if (hFile == INVALID_HANDLE_VALUE)        //�����ļ�ʧ��
  {
    LastErrorCode = GetLastError();
    return FALSE;
  }

  BindToFile = TRUE;
  ResetDatabase(0);
}

BOOL REX_DebugInfoDatabase::ResetDatabase(DWORD rFlag)
{
  PWCHAR pos;

  if (!BindToFile) return FALSE;

  if (ModuleList) HMM.hfree(ModuleList);
  if (DS) HMM.hfree(DS);
  if (DB) HMM.hfree(DB);
  if (SM) HMM.hfree(SM);

  ModuleList = NULL;
  DS = NULL;
  DB = NULL;
  SM = NULL;

  FileHdr.fMagic = CSDI_DBMAGIC;
  FileHdr.dbVer0 = CSDI_VER0;
  FileHdr.dbVer1 = CSDI_VER1;
  FileHdr.dbFlag0 = 0;
  FileHdr.dbFlag1 = 0;
  FileHdr.NumMod = 0;
  FileHdr.NumSec = 0;
  FileHdr.NumBlk = 0;
  FileHdr.NumMem = 0;
  FileHdr.ExtraSection = NULL;
  FileHdr.ExtraBlock = NULL;
  FileHdr.ExtraMember = NULL;
  FileHdr.ExtraData = NULL;
  FileHdr.SizeSection = 0;
  FileHdr.SizeBlock = 0;
  FileHdr.SizeMember = 0;
  FileHdr.SizeData = 0;

  memset(FileHdr.dwReserve, 0, sizeof(DWORD) * 8);

  pos = wcschr(fpath, L'\\');
  if (pos)
  {
    pos++;
    wcscpy_s(FileHdr.ModuleName, 256, pos);
  }
  else
    wcscpy_s(FileHdr.ModuleName, 256, fpath);

}

LONG REX_DebugInfoDatabase::AddModuleToDatabase(PWCHAR szModPath, DWORD adFlag)
{
  _UNICRC64 ui64;
  LONG ridx;
  HANDLE hmFile;
  DWORD fhSize;
  DWORD flSize;
  DWORD cIndex;
  PBYTE pFileBuff;
  DEBUG_INFO_MODULE_MEMORY cFileMem;

  hmFile = CreateFile(fpath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
    FILE_ATTRIBUTE_NORMAL, NULL);           //���Ѵ����ļ�

  if (hmFile == INVALID_HANDLE_VALUE) return -1;

  flSize = GetFileSize(hmFile, &fhSize);

  if (fhSize || !flSize)
  {
    CloseHandle(hmFile);
    return -2;
  }

  pFileBuff = (PBYTE)malloc(flSize);
  if (!pFileBuff)
  {
    CloseHandle(hmFile);
    return -3;
  }

  SetFilePointer(hmFile, 0, NULL, FILE_BEGIN);
  ReadFile(hmFile, pFileBuff, flSize, &fhSize, NULL);

  if (!fhSize)              //��ȡ�ļ�ʧ��
  {
    free(pFileBuff);
    CloseHandle(hmFile);
    return -4;
  }

  if (fhSize != flSize)     //�ļ���С��һ��
  {
    pFileBuff = (PBYTE)realloc(pFileBuff, fhSize);
    flSize = fhSize;

    if (!pFileBuff)
    {
      CloseHandle(hmFile);
      return -5;
    }
  }

  if (!CheckPEFormatByBuffer(pFileBuff, flSize, 0))   //PE��ʽ���Ϸ�
  {
    free(pFileBuff);
    CloseHandle(hmFile);
    return -6;
  }
 
  /* �������е��Խӿ� */
  for (ridx = 0; ridx < MAX_DEBUGIF; ridx++)
    cFileMem.DebugInterface[ridx] = NULL;

  cFileMem.ExtSecHdr = NULL;
  cFileMem.DatBlkHdr = NULL;
  cFileMem.StrMemHdr = NULL;

  /* ħ���� */
  cFileMem.ModuleDB.fMagic = CSDI_FLMAGIC;

  /* ��־0 */
  cFileMem.ModuleDB.FileFlag0 = 0;

  /* ����CRC64 */
  CRC64_Init(&ui64.cNum64);
  CRC64_Calc(&ui64.cNum64, pFileBuff, flSize);
  CRC64_Final(&ui64.cNum64);
  cFileMem.ModuleDB.CRC64 = ui64.cNum64;

  /* ����MD5 */
  if (CHECK_NOPARAM(adFlag, CSDB_ADFLAG_NOMD5) || !GetDataMD5Sum(pFileBuff, flSize, &cFileMem.ModuleDB.MD5))
    memset(&cFileMem.ModuleDB.MD5, 0, sizeof(UNIMD5));

  /* ��־1 */
  cFileMem.ModuleDB.FileFlag1 = 0;

  /* ���ö����� */
  cFileMem.ModuleDB.SectionNumber = 0;

  /* ���ÿ����� */
  cFileMem.ModuleDB.BlockNumber = 0;

  /* DOS�ļ�ͷ */
  cFileMem.ModuleDB.BkDosHdr = *(PIMAGE_DOS_HEADER(pFileBuff));

  cIndex = cFileMem.ModuleDB.BkDosHdr.e_lfanew;

  /* ǩ�� */
  cFileMem.ModuleDB.BkSignature = *(PDWORD(&pFileBuff[cIndex]));

  cIndex += 4;

  /* ӳ���ļ�ͷ */
  cFileMem.ModuleDB.BkFileHdr = *(PIMAGE_FILE_HEADER(&pFileBuff[cIndex]));

  cIndex += IMAGE_SIZEOF_FILE_HEADER;

  /* �����ѡͷ */
  memset(&cFileMem.ModuleDB.OptHdr, 0, sizeof(DEBUG_INFO_MODULE::_UnionOptHdr));

  /* ���ƿ�ѡͷ */
  memcpy_s(&cFileMem.ModuleDB.OptHdr, sizeof(DEBUG_INFO_MODULE::_UnionOptHdr), &pFileBuff[cIndex],
    cFileMem.ModuleDB.BkFileHdr.SizeOfOptionalHeader);

  wcscpy_s(cFileMem.ModuleDB.FirstPath, MAX_PATH, szModPath);

  cFileMem.ModuleDB.PDB_Path[0] = 0;

  if (!ModuleList || !FileHdr.NumMod)     //���������ģ���б�
  {
    if (ModuleList) HMM.hfree(ModuleList);
    FileHdr.NumMod = 0;
    ModuleList = (PDEBUG_INFO_MODULE_MEMORY)HMM.hmalloc(sizeof(DIDBMM));
    if (!ModuleList) return -10;
    ModuleList[0] = cFileMem;
    FileHdr.NumMod++;
    return 0;
  }
  else
  {
    ModuleList = (PDEBUG_INFO_MODULE_MEMORY)HMM.hrealloc(ModuleList, sizeof(DIDBMM) * (FileHdr.NumMod + 1));
    if (!ModuleList) return -11;
    ridx = LONG(FileHdr.NumMod);
    ModuleList[ridx] = cFileMem;
    FileHdr.NumMod++;
    return ridx;
  }
}