#include "../sr_pch.h"

MC_VBInfo * MC_VBInfo::This = NULL;

MC_VBInfo::~MC_VBInfo()
{
  if (this->m_hWnd)
  {
    DestroyWindow(this->m_hWnd);
    this->m_hWnd = NULL;
  }

  if (this->hm_pop_4)
  {
    DestroyMenu(this->hm_pop_4);
    hm_pop_4 = NULL;
  }
  This = NULL;
}

HWND MC_VBInfo::CreateForm(int x, int y, int cx, int cy, LPCTCH wName, DWORD Style)
{
  if (this->m_hWnd)
  {
    this->SetTop();
    return this->m_hWnd;
  }

  MDICREATESTRUCT MCS;

  MCS.szClass = (PTCHAR)mf->rcls_mc_vbinfo;
  MCS.szTitle = wName;
  MCS.hOwner = mf->MdlBase;
  MCS.style = Style;
  MCS.cx = cx;
  MCS.cy = cy;
  MCS.x = x;
  MCS.y = y;
  MCS.lParam = (LPARAM)this;

  this->m_hWnd = (HWND)::SendMessage(hw_MDI, WM_MDICREATE, 0, (LPARAM)&MCS);
  return this->m_hWnd;
}

void MC_VBInfo::ParseHeader(PVBHDR pVbHeader)
{
#define PRIV_BUFLEN         64
  WORD frmCount = 0;
  WORD basCount = 0;
  WORD clsCount = 0;
  WORD ctlCount = 0;
  PVBOBJ pVbObject;
  PVB_TV_TYPE pTv;
  WORD i;
  WORD ObjCount;
  DWORD j;
  WORD k;
  DWORD BakVal;
  HTREEITEM LastForm;
  HTREEITEM LastItem;
  TV_INSERTSTRUCT tvis;
  TCHAR stmp0[PRIV_BUFLEN];
  TCHAR stmp1[PRIV_BUFLEN];
  TCHAR entmp[PRIV_BUFLEN];

  __try
  {
    if (pVbHeader->Sign.dwSign != VB_MAGIC)
    {
      mf->SetStateText(_T("VB�ṹ��־����ȷ!"), RGB(255, 0, 0));
      return;
    }

    ResetControl();

    //ZeroMemory(&tvis, sizeof(TV_INSERTSTRUCT));

    pri_vbheader = pVbHeader;
    _stprintf_s(stmp0, PRIV_BUFLEN, HEXFORMAT, pri_vbheader);
    SendMessage(vbsp, WM_SETTEXT, 0, (LPARAM)stmp0);
    pVbObject = pVbHeader->pProjInfo->pObjectTable->pObject;
    ObjCount = pVbHeader->pProjInfo->pObjectTable->ObjectCount1;

    tvis.hParent = 0;
    tvis.hInsertAfter = TVI_ROOT;
    tvis.item.mask = TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM;
    tvis.item.iImage = MainForm::bpi_root;
    tvis.item.iSelectedImage = MainForm::bpi_root;

    ALLOC_PARAM(tvis, pTv, VBPC_NULLITEM, 0);
    tvis.item.pszText = _T("VB�ṹ");
    hti_struct = TreeView_InsertItem(tv_vb, &tvis);

    tvis.hParent = hti_struct;
    tvis.item.iImage = MainForm::bpi_vbs;
    tvis.item.iSelectedImage = MainForm::bpi_vbs;

    ALLOC_PARAM(tvis, pTv, VBPC_STRUCT, VBII_VBHDR);
    tvis.item.pszText = _T("VB ͷ��");                    //����VB�����ṹ�ڵ�
    pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);

    ALLOC_PARAM(tvis, pTv, VBPC_STRUCT, VBII_PRJI);
    tvis.item.pszText = _T("VB ������Ϣ");
    pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);

    ALLOC_PARAM(tvis, pTv, VBPC_STRUCT, VBII_COMD);
    tvis.item.pszText = _T("VB COMע������");
    pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);

    ALLOC_PARAM(tvis, pTv, VBPC_STRUCT, VBII_COMI);
    tvis.item.pszText = _T("VB COMע����Ϣ");
    pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);

    ALLOC_PARAM(tvis, pTv, VBPC_STRUCT, VBII_OBJTAB);
    tvis.item.pszText = _T("VB ����������");
    pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);

    ALLOC_PARAM(tvis, pTv, VBPC_STRUCT, VBII_OBJS);
    _stprintf_s(stmp0, PRIV_BUFLEN, _T("VB ����  (%hu)"), ObjCount);
    tvis.item.pszText = stmp0;
    hti_object = TreeView_InsertItem(tv_vb, &tvis);
    pTv->TV.hItem = hti_object;

    tvis.hParent = hti_object;
    tvis.item.iImage = MainForm::bpi_object;
    tvis.item.iSelectedImage = MainForm::bpi_object;

    mf->SetDbgState(DS_Busy);

    for (i = 0; i < ObjCount; i++)            //��һ�α���Object������
    {
      ALLOC_PARAM(tvis, pTv, VBPC_OBJECT, i);
      tvis.item.pszText = (PTCHAR)pVbObject[i].aObjectName;
      pTv->TV.hItem = TreeView_InsertItemA(tv_vb, &tvis);

      if ((pVbObject[i].ObjectType & 0x80) == 0x80)
      {
        frmCount++;
        continue;
      }

      if ((pVbObject[i].ObjectType & 0x02) == 0)
      {
        basCount++;
        continue;
      }

      if ((pVbObject[i].ObjectType & 0x001DA003) == 0x001DA003)
      {
        ctlCount++;
        continue;
      }

      if ((pVbObject[i].ObjectType & 0x00018003) == 0x00018003)
      {
        clsCount++;
        continue;
      }
    }

    tvis.hParent = 0;
    tvis.hInsertAfter = TVI_LAST;
    tvis.item.iImage = MainForm::bpi_root;
    tvis.item.iSelectedImage = MainForm::bpi_root;
    tvis.item.pszText = stmp0;

    ALLOC_PARAM(tvis, pTv, VBPC_NULLITEM, 1);
    _stprintf_s(stmp0, PRIV_BUFLEN, _T("����  [Form]  (%hu)"), frmCount);
    hti_frm = TreeView_InsertItem(tv_vb, &tvis);
    pTv->TV.hItem = hti_frm;

    ALLOC_PARAM(tvis, pTv, VBPC_NULLITEM, 2);
    _stprintf_s(stmp0, PRIV_BUFLEN, _T("ģ��  [Module]  (%hu)"), basCount);
    hti_bas = TreeView_InsertItem(tv_vb, &tvis);
    pTv->TV.hItem = hti_bas;

    ALLOC_PARAM(tvis, pTv, VBPC_NULLITEM, 3);
    _stprintf_s(stmp0, PRIV_BUFLEN, _T("��ģ��  [Class]  (%hu)"), clsCount);
    hti_cls = TreeView_InsertItem(tv_vb, &tvis);
    pTv->TV.hItem = hti_cls;

    ALLOC_PARAM(tvis, pTv, VBPC_NULLITEM, 4);
    _stprintf_s(stmp0, PRIV_BUFLEN, _T("�û��ؼ�  [UserControl]  (%hu)"), ctlCount);
    hti_ctl = TreeView_InsertItem(tv_vb, &tvis);
    pTv->TV.hItem = hti_ctl;

    for (i = 0; i < ObjCount; i++)        //�ڶ��α���Object
    {
      PVBOOI pooi;    //VB�����ѡ��Ϣͷ
      PVBC pctl;
      PPVBEP ppep;
      PVBOBJLST pVbObjL;

      if ((pVbObject[i].ObjectType & 0x80) == 0x80)   //�жϴ���
      {
        tvis.hParent = hti_frm;
        tvis.item.iImage = MainForm::bpi_frm;
        tvis.item.iSelectedImage = MainForm::bpi_frm;
        tvis.item.pszText = stmp0;
        ALLOC_PARAM(tvis, pTv, VBPC_ROOTFORM, i);

        if (!(pVbObjL = mf->GetObjectListByObject(&pVbObject[i])))
        {
          VBOBJLST VbObjL;
          PTCHAR pstmp;
          size_t slen = strlen(pVbObject[i].aObjectName);

          memset(&VbObjL, 0, sizeof(VbObjL));

          if (!slen)
          {
            pstmp = (PTCHAR)mf->m_hmm->hcalloc(16, sizeof(TCHAR));
            _stprintf_s(pstmp, 16, _T("_frm_%hu"), pVbObject[i].pObjectInfo->ObjectIndex);
          }
          else
          {
            pstmp = (PTCHAR)mf->m_hmm->hcalloc(slen + 1);
            mbstowcs_s((size_t *)&BakVal, pstmp, slen + 1, pVbObject[i].aObjectName, _TRUNCATE);
          }

          VbObjL.VbHead = pVbHeader;
          VbObjL.VbObj = &pVbObject[i];
          VbObjL.iIndex = pVbObject[i].pObjectInfo->ObjectIndex;
          VbObjL.ObjName = pstmp;

          pVbObjL = mf->AddObjectList(&VbObjL);
        }
        tvis.item.pszText = pVbObjL->ObjName;
        LastForm = TreeView_InsertItem(tv_vb, &tvis);
        pTv->TV.hItem = LastForm;

        pooi = (PVBOOI)((DWORD)pVbObject[i].pObjectInfo + sizeof(VBOI));
        pctl = pooi->pControlArray;

        for (j = 0; j < pooi->ControlCount; j++)          //�����ؼ�
        {
          tvis.hParent = LastForm;
          tvis.item.iImage = MainForm::bpi_ukctl;
          tvis.item.iSelectedImage = MainForm::bpi_ukctl;
          tvis.item.pszText = stmp0;
          ALLOC_PARAM(tvis, pTv, VBPC_FORM, j);
          if (strlen(pctl[j].pName) == 0)
            _stprintf_s(stmp0, PRIV_BUFLEN, _T("_ctl%u"), j + 1);
          else
            mbstowcs_s((size_t *)&BakVal, stmp0, (size_t)PRIV_BUFLEN, pctl[j].pName, _TRUNCATE);
          LastItem = TreeView_InsertItem(tv_vb, &tvis);
          pTv->TV.hItem = LastItem;       //���浱ǰ�ؼ�
          _tcscpy_s(stmp1, PRIV_BUFLEN, stmp0);      //���ݿؼ���
          tvis.hParent = LastItem;

          ppep = (PPVBEP)((DWORD)pctl[j].pEventTable + sizeof(VB_EVENT_TABLE));
          for (k = 0; k < pctl[j].EventCount; k++)          //�����ؼ��¼�
          {
            if (ppep[k] == NULL || ppep[k]->pDescInfo == NULL) continue;
            PVBPL pVbProcL;
            if (!(pVbProcL = mf->GetProcListByAddress(pVbObjL->ObjName, ppep[k]->pDescInfo)))
            {
              VBPL VbProcL;
              PTCHAR pstmp = 0;
              PVOID TT;
              DWORD LE;

              memset(&VbProcL, 0, sizeof(VBPL));
              pstmp = (PTCHAR)mf->m_hmm->hcalloc(64, sizeof(TCHAR));

              if (!GetMemberNameByIndex(*pctl[j].pGUID, (DWORD)k, entmp, 64, 0))
                _stprintf_s(entmp, 64, _T("Event_%hu"), k);
              _stprintf_s(pstmp, 64, _T("%s_%s"), stmp1, entmp);
              VbProcL.pVbCtl = &pctl[j];
              VbProcL.iIndex = k;
              VbProcL.ProcDesc = ppep[k]->pDescInfo;
              VbProcL.EvtName = pstmp;
              pVbProcL = mf->AddProcListByObject(pVbObjL, &VbProcL);
            }

            tvis.item.iImage = MainForm::bpi_event;
            tvis.item.iSelectedImage = MainForm::bpi_event;
            ALLOC_PARAM(tvis, pTv, VBPC_FRMCTL, k);
            tvis.item.pszText = pVbProcL->EvtName;
            pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);
            tvis.item.pszText = stmp0;
          }
        }

      }
      else if ((pVbObject[i].ObjectType & 0x02) == 0)      //�ж�ģ��
      {
        tvis.hParent = hti_bas;
        tvis.item.iImage = MainForm::bpi_bas;
        tvis.item.iSelectedImage = MainForm::bpi_bas;
        ALLOC_PARAM(tvis, pTv, VBPC_BAS, i);

        if (strlen(pVbObject[i].aObjectName) == 0)
        {
          _stprintf_s(stmp0, PRIV_BUFLEN, _T("_bas%hu"), i + 1);
          tvis.item.pszText = stmp0;
          pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);
        }
        else
        {
          tvis.item.pszText = (PTCHAR)pVbObject[i].aObjectName;
          pTv->TV.hItem = TreeView_InsertItemA(tv_vb, &tvis);
        }
      }
      else if ((pVbObject[i].ObjectType & 0x001DA003) == 0x001DA003)       //�ж��û��ؼ�
      {
        tvis.hParent = hti_ctl;
        tvis.item.iImage = MainForm::bpi_ctl;
        tvis.item.iSelectedImage = MainForm::bpi_ctl;
        ALLOC_PARAM(tvis, pTv, VBPC_UC, i);

        if (strlen(pVbObject[i].aObjectName) == 0)
        {
          _stprintf_s(stmp0, PRIV_BUFLEN, _T("_ctl%hu"), i + 1);
          tvis.item.pszText = stmp0;
          pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);
        }
        else
        {
          tvis.item.pszText = (PTCHAR)pVbObject[i].aObjectName;
          pTv->TV.hItem = TreeView_InsertItemA(tv_vb, &tvis);
        }
        continue;
      }
      else if ((pVbObject[i].ObjectType & 0x00018003) == 0x00018003)       //�ж���ģ��
      {
        tvis.hParent = hti_cls;
        tvis.item.iImage = MainForm::bpi_cls;
        tvis.item.iSelectedImage = MainForm::bpi_cls;
        ALLOC_PARAM(tvis, pTv, VBPC_CLS, i);

        if (strlen(pVbObject[i].aObjectName) == 0)
        {
          _stprintf_s(stmp0, PRIV_BUFLEN, _T("_cls%hu"), i + 1);
          tvis.item.pszText = stmp0;
          pTv->TV.hItem = TreeView_InsertItem(tv_vb, &tvis);
        }
        else
        {
          tvis.item.pszText = (PTCHAR)pVbObject[i].aObjectName;
          pTv->TV.hItem = TreeView_InsertItemA(tv_vb, &tvis);
        }

      }
      else
        continue;
    }
    mf->SetDbgState(DS_Idle);

  }

  __except (TestExpect(GetExceptionCode()))
  {
    ResetControl();
    mf->SetStateText(_T("�ڽ���VB�ṹʱ�����ڴ����."), RGB(255, 0, 0));
    return;
  }
#undef PRIV_BUFLEN
}

void MC_VBInfo::ParseModule(PVOID ModuleBase)
{
  if (!this->m_hWnd) return;

  __try
  {
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)ModuleBase;
    if (pDos->e_magic != IMAGE_DOS_SIGNATURE) return;
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)((DWORD)ModuleBase + pDos->e_lfanew);
    PBYTE OEP = (PBYTE)((DWORD)ModuleBase + pNt->OptionalHeader.AddressOfEntryPoint);
    PVBHDR VBHDR = (PVBHDR)*(PDWORD)((DWORD)OEP + 1);

    if (OEP[0] != 0x68 || OEP[5] != 0xE8) //push xxxxxxxx; call xxxxxxxx
    {
      mf->SetStateText(_T("δ��λ������VB�ṹ�Ĵ���!"), RGB(255, 0, 0));
      return;
    }

    if (VBHDR->Sign.dwSign != VB_MAGIC)
    {
      mf->SetStateText(_T("VB�ṹ��־����ȷ!"), RGB(255, 0, 0));
      return;
    }

    ParseHeader(VBHDR);
  }
  __except (TestExpect(GetExceptionCode()))
  {
    mf->SetStateText(_T("�ڽ���VBͷ���ṹʱ��ȡ�ڴ����."), RGB(255, 0, 0));
    return;
  }
}

LRESULT CALLBACK MC_VBInfo::vbWndProc(HWND phWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
  switch (Msg)
  {
  case WM_CREATE:
  {
    This->vbsp = CreateWindowEx(WS_EX_CLIENTEDGE, CN_EDIT, T_NULL, DEF_VCHILD | ES_CENTER, 80, 1, 80, 20, phWnd, 0, DllBaseAddr, 0);
    This->btn_vbok = CreateWindowEx(0, CN_BUTTON, _T("����"), DEF_VCHILD, 170, 1, 50, 20, phWnd, 0, DllBaseAddr, 0);
    This->btn_vbsh = CreateWindowEx(0, CN_BUTTON, _T("HOOK�ṹָ��"), DEF_VCHILD, 230, 1, 100, 20, phWnd, 0, DllBaseAddr, 0);
    This->tv_vb = CreateWindowEx(WS_EX_CLIENTEDGE, WC_TREEVIEW, TN_VBTREE, TV_STYLE, 0, 0, 0, 0, phWnd, NULL, DllBaseAddr, 0);
    This->lv_vb = CreateWindowEx(WS_EX_CLIENTEDGE, WC_LISTVIEW, LN_VBLIST, LV_STYLE, 0, 0, 0, 0, phWnd, NULL, DllBaseAddr, 0);
    ListView_SetExtendedListViewStyle(This->lv_vb, LVS_EX_FULLROWSELECT);
    This->hm_pop_4 = GetSubMenu(MainForm::hm_pop, 4);

    if (!This->vbsp || !This->btn_vbok || !This->btn_vbsh || !This->tv_vb || !This->lv_vb)
      return -1;

    SendMessage(This->vbsp, WM_SETFONT, (WPARAM)MainForm::hf_tam, 1);
    SendMessage(This->vbsp, EM_SETLIMITTEXT, 8, 0);
    SetWindowLong(This->btn_vbok, GWL_ID, PDIDC_VBOKBTN);
    SendMessage(This->btn_vbok, WM_SETFONT, (WPARAM)MainForm::hf_tas, 1);
    SetWindowLong(This->btn_vbsh, GWL_ID, PDIDC_VBSHBTN);
    SendMessage(This->btn_vbsh, WM_SETFONT, (WPARAM)MainForm::hf_tas, 1);

    This->ctv_vb.Attach(This->tv_vb);
    This->ctv_vb.SetFont(&MainForm::cf_tam, 1);
    This->ctv_vb.SetBkColor(RGB(225, 250, 250));
    This->ctv_vb.SetImageList(&MainForm::cImageList, TVSIL_NORMAL);

    This->clv_vb.Attach(This->lv_vb);
    This->clv_vb.SetImageList(&MainForm::cImageList, TVSIL_NORMAL);
  }
    return 0;
  case WM_DESTROY:
    This->ctv_vb.Detach();
    This->clv_vb.Detach();
    This->m_hWnd = NULL;
    This->vbsp = NULL;
    This->btn_vbok = NULL;
    This->tv_vb = NULL;
    This->lv_vb = NULL;
    return 0;
  case WM_NOTIFY:
  {
    if (lParam == 0) break;

    LPNMHDR pNm = (LPNMHDR)lParam;

    switch (pNm->code)
    {
    case TVN_DELETEITEMA:
    {
      LPNMTREEVIEWA pnmtv = (LPNMTREEVIEWA)lParam;
      if (pnmtv->itemOld.lParam)
      {
        PVB_TV_TYPE pTv = (PVB_TV_TYPE)pnmtv->itemOld.lParam;
        if (pTv)
          if (pTv->TV.Sign == MY_MAGIC)
            free((PVOID)pnmtv->itemOld.lParam);
      }
    }
      break;
    case TVN_DELETEITEMW:
    {
      LPNMTREEVIEWW pnmtv = (LPNMTREEVIEWW)lParam;
      if (pnmtv->itemOld.lParam)
      {
        PVB_TV_TYPE pTv = (PVB_TV_TYPE)pnmtv->itemOld.lParam;
        if (pTv)
          if (pTv->TV.Sign == MY_MAGIC)
            free((PVOID)pnmtv->itemOld.lParam);
      }
    }
      break;
    case NM_RCLICK:
    {
      RECT rect;

      if (pNm->hwndFrom == This->tv_vb)
      {
        PVB_TV_TYPE pTv;
        TVHITTESTINFO tvhti;
        TVITEM tvi;

        GetCursorPos(&tvhti.pt);
        GetWindowRect(This->tv_vb, &rect);
        tvhti.pt.x -= rect.left;
        tvhti.pt.y -= rect.top;
        This->ctv_vb.HitTest(&tvhti);
        if ((tvhti.flags & TVHT_ONITEM) == 0) return 1;
        This->ctv_vb.SelectItem(tvhti.hItem);
        tvi.mask = TVIF_PARAM;
        tvi.hItem = tvhti.hItem;
        This->ctv_vb.GetItem(&tvi);
        pTv = (PVB_TV_TYPE)tvi.lParam;
        if (!pTv || pTv->TV.Sign != MY_MAGIC) return 1;
        tvhti.pt.x += rect.left;
        tvhti.pt.y += rect.top;
        if (pTv->TV.NCode == VBPC_FRMCTL)
          TrackPopupMenu(This->hm_pop_4, TPM_LEFTALIGN, tvhti.pt.x, tvhti.pt.y, 0, phWnd, NULL);
      }
    }
      return 1;
    }
  }
    break;
  case WM_SIZE:
    if (wParam != SIZE_MINIMIZED)
    {
      WORD Width = LOWORD(lParam);
      WORD Height = HIWORD(lParam);

      MoveWindow(This->tv_vb, 0, 22, 280, Height - 22, TRUE);
      MoveWindow(This->lv_vb, 281, 22, Width - 281, Height - 22, TRUE);
    }
    break;
  case WM_PAINT:
  {
    PAINTSTRUCT ps;
    HDC hDC = BeginPaint(phWnd, &ps);

    if (!hDC) break;
    SelectObject(hDC, MainForm::hf_tam);
    SetTextColor(hDC, RGB(0, 0, 255));
    TextOut(hDC, 4, 3, _T("VB�ṹָ��:"), 7);
    EndPaint(phWnd, &ps);
  }
    return 0;
  case WM_SIZING:
  {
    if (wParam >= WMSZ_LEFT && wParam <= WMSZ_BOTTOMRIGHT)
    {
      LPRECT lprc = (LPRECT)lParam;
      long Width = lprc->right - lprc->left;
      long Height = lprc->bottom - lprc->top;

      if (Width < 800) lprc->right = lprc->left + 800;
      if (Height < 400) lprc->bottom = lprc->top + 400;
    }
  }
    return 1;
  }

  return DefMDIChildProc(phWnd, Msg, wParam, lParam);
}

void MC_VBInfo::ResetControl()
{
  ctv_vb.DeleteAllItems();
  clv_vb.DeleteAllItems();
  while (clv_vb.DeleteColumn(0));
}

void MC_VBInfo::vbInsertColumn(DWORD iType)
{
  LV_COLUMN lvc;
  lvc.mask = LVCF_TEXT | LVCF_WIDTH;

  clv_vb.DeleteAllItems();
  while (clv_vb.DeleteColumn(0));

  switch (iType)
  {
  case 1:
    lvc.pszText = _T("��Ա����");
    lvc.cx = DefWidth;
    clv_vb.InsertColumn(0, &lvc);

    lvc.pszText = _T("��Ա��ֵ");
    lvc.cx = 128;
    clv_vb.InsertColumn(1, &lvc);

    lvc.pszText = _T("��Ա����");
    lvc.cx = 256;
    clv_vb.InsertColumn(2, &lvc);
    break;
  default:
    lvc.pszText = _T("��Ա����");
    lvc.cx = DefWidth;
    clv_vb.InsertColumn(0, &lvc);

    lvc.pszText = _T("��Ա��ֵ");
    lvc.cx = 128;
    clv_vb.InsertColumn(1, &lvc);

    lvc.pszText = _T("��Ա����");
    lvc.cx = 256;
    clv_vb.InsertColumn(2, &lvc);
    break;
  }
}

void MC_VBInfo::RefreshStructList()
{
  //LV_ITEM lvi;

}