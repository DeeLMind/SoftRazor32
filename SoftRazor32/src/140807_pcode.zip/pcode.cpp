#include "mspcode.h"

/*
Reference From Semi VB Decompiler
Thank: vbgamer45
http://www.vbforums.com/member.php?51546-vbgamer45
*/

#define MSPC_MAX_BUFFER     512

#ifndef __cplusplus
#define inline __inline
#endif

extern const VB_PCODE_INSTRUCTIONSET PCodeStdInst[251];
extern const VB_PCODE_INSTRUCTIONSET * PCodeLeadInst[5];
extern BOOL GetPropertyText(GUID guid, WORD VTOS, PWCHAR pText, DWORD tMax, PWCHAR pNote, DWORD nMax);

static inline BYTE GetByteFormPoint(void * pany)
{
  return *(BYTE *)pany;
}

static inline int16_t GetSI16FormP16(void * pint16)
{
  return *(int16_t *)pint16;
}

static inline uint16_t GetUI16FormP16(void * pint16)
{
  return *(uint16_t *)pint16;
}

static inline uint32_t GetUI32FormPSI16(void * pint16)
{
  return (uint32_t)*(int16_t *)pint16;
}

static inline uint32_t GetUI32FormPUI16(void * pint16)
{
  return (uint32_t)*(uint16_t *)pint16;
}

static inline int32_t GetSI32FormPSI16(void * pint16)
{
  return (int32_t)*(int16_t *)pint16;
}

static inline int32_t GetSI32FormPUI16(void * pint16)
{
  return (int32_t)*(uint16_t *)pint16;
}

static inline int32_t GetSI32FormP32(void * pint32)
{
  return *(int32_t *)pint32;
}

static inline uint32_t GetUI32FormP32(void * pint32)
{
  return *(uint32_t *)pint32;
}

BOOL NTAPI GetProcName(UINT hMod, UINT pAddr, PCHAR * oppchr, PCHAR * pmName)
{
  if (!hMod || !pAddr || !oppchr) return FALSE;

  PIMAGE_NT_HEADERS32 nthdr = (PIMAGE_NT_HEADERS32)(hMod + ((PIMAGE_DOS_HEADER)hMod)->e_lfanew);
  if (nthdr->FileHeader.SizeOfOptionalHeader < 0xE0) return FALSE;
  if (nthdr->OptionalHeader.NumberOfRvaAndSizes < 2) return FALSE;
  PIMAGE_IMPORT_DESCRIPTOR pImpDir = (PIMAGE_IMPORT_DESCRIPTOR)(hMod + nthdr->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
  PIMAGE_THUNK_DATA32 pOrgThunk;
  PIMAGE_THUNK_DATA32 pThunk;
  UINT i = 0;
  UINT j;

  while (pImpDir[i].OriginalFirstThunk)
  {
    j = 0;
    pOrgThunk = (PIMAGE_THUNK_DATA32)(hMod + pImpDir[i].OriginalFirstThunk);
    pThunk = (PIMAGE_THUNK_DATA32)(hMod + pImpDir[i].FirstThunk);

    while (pOrgThunk[j].u1.AddressOfData)
    {
      if (pThunk[j].u1.Function == pAddr)
      {
        if (IMAGE_SNAP_BY_ORDINAL32(pOrgThunk[j].u1.Ordinal))
          *oppchr = (PCHAR)(IMAGE_ORDINAL32(pOrgThunk[j].u1.Ordinal));
        else
          *oppchr = (PCHAR)&((PIMAGE_IMPORT_BY_NAME(hMod + pOrgThunk[j].u1.AddressOfData))->Name[0]);

        *pmName = (PCHAR)(hMod + pImpDir[i].Name);
        return TRUE;
      }
      j++;
    }
    i++;
  }
  return FALSE;
}

static void NTAPI MakeArg(int32_t ival, wchar_t * iText, size_t maxc)
{
  WCHAR stmp[16];

  if (ival < 0)
    swprintf_s(stmp, 16, L"var_%X", -ival);
  else
    swprintf_s(stmp, 16, L"arg_%X", ival);

  wcscat_s(iText, maxc, stmp);
}

static void NTAPI MakeAddr(PPDO pcdo, uint32_t uval)
{
  int32_t si32;
  WCHAR stmp[MSPC_MAX_BUFFER];

  stmp[0] = 0;
  if (uval >= pcdo->mod_base && (uval < pcdo->mod_base + pcdo->mod_size))
  {
    if (*(BYTE *)uval == 0xBA && *(BYTE *)(uval + 5) == 0xB9)
    {
      si32 = GetSI32FormP32((void *)(uval + 1));
      if (!pcdo->func_qs || !pcdo->func_qs(si32, stmp, MSPC_MAX_BUFFER))
        swprintf_s(stmp, MSPC_MAX_BUFFER, L"proc_%08X", si32);
    }
    else if (*(short *)uval == 0x25FF)
    {
      si32 = GetSI32FormP32((void *)(uval + 2));
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"eximp_%08X", si32);
    }
    else
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"unkn_%08X", uval);
  }
  else
  {
    swprintf_s(stmp, MSPC_MAX_BUFFER, L"??=%08X", uval);
  }

  wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
}

static void NTAPI MakeAddrToVB(PPDO pcdo, uint32_t ival)
{
  int si32;
  WCHAR stmp[MSPC_MAX_BUFFER];

  if (ival >= pcdo->mod_base && (ival < pcdo->mod_base + pcdo->mod_size))
  {
    stmp[0] = 0;

    if (*(BYTE *)ival == 0xBA && *(BYTE *)(ival + 5) == 0xB9)
    {
      si32 = GetSI32FormP32((void *)(ival + 1));
      if (!pcdo->func_qs || !pcdo->func_qs(si32, stmp, MSPC_MAX_BUFFER))
        swprintf_s(stmp, MSPC_MAX_BUFFER, L"proc_%08X", si32);
    }
    else if (*(short *)ival == 0x25FF)
    {
      int ImpAddr;
      PCHAR pImp = 0;
      PCHAR pmName = 0;
      size_t bval;

      si32 = GetSI32FormP32((void *)(ival + 2));

      ImpAddr = *(int *)si32;

      if (GetProcName(pcdo->mod_base, ImpAddr, &pImp, &pmName))
      {
        mbstowcs_s(&bval, stmp, MSPC_MAX_BUFFER, pmName, _TRUNCATE);

        if ((UINT)pImp > 0xFFFF)
        {
          wcscat_s(stmp, MSPC_MAX_BUFFER, L"->");
          wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
          mbstowcs_s(&bval, stmp, MSPC_MAX_BUFFER, pImp, _TRUNCATE);
        }
        else
        {
          wcscat_s(stmp, MSPC_MAX_BUFFER, L"#>");
          wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
          swprintf_s(stmp, MSPC_MAX_BUFFER, L"%X", pImp);
        }
      }
      else if (!pcdo->func_qs || !pcdo->func_qs(si32, stmp, MSPC_MAX_BUFFER))
        swprintf_s(stmp, MSPC_MAX_BUFFER, L"eximp_%08X", si32);
    }
    else
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"unkn_%08X", ival);
  }
  else
  {
    swprintf_s(stmp, MSPC_MAX_BUFFER, L"??=%08X", ival);
  }
  wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
}

static void NTAPI ReturnApiCall(PPDO pcdo, uint32_t iAddr)
{
  uint32_t ui32, ui32tmp;
  size_t bval;
  WCHAR stmp[MSPC_MAX_BUFFER];

  if ((*(char *)iAddr == 0xA1) && (*(char *)(iAddr + 11) == 0x68))
  {
    ui32 = GetUI32FormP32((void *)(iAddr + 12));
    if ((ui32 >= pcdo->mod_base) && (ui32 < pcdo->mod_base + pcdo->mod_size))
    {
      ui32tmp = GetUI32FormP32((void *)ui32);
      mbstowcs_s(&bval, stmp, MSPC_MAX_BUFFER, (char *)ui32tmp, _TRUNCATE);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);

      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, L"->");

      ui32tmp = GetUI32FormP32((void *)(ui32 + 4));
      mbstowcs_s(&bval, stmp, MSPC_MAX_BUFFER, (char *)ui32tmp, _TRUNCATE);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      return;
    }
  }
  MakeAddrToVB(pcdo, iAddr);
}

/*
pcf_init_depcode_object
��ʼ���������
����ֵ:
0Ϊ�ɹ�,��0ʧ��
*/
int pcf_init_depcode_object(PPDO pcdo, PWCHAR pstr, UINT slen, PBYTE inBuf, UINT inMax, UINT mb, UINT ms, PVBPDI pdi)
{
  if (!pcdo) return -1;
  if (!pstr || !slen) return -2;
  if (!inBuf || !inMax) return -3;
  if (!mb || !ms) return -4;
  if (!pdi) return -5;

  pcdo->inp_opbuf = inBuf;
  pcdo->inp_idx = 0;
  pcdo->inp_count = inMax;
  pcdo->len_std = 0;
  pcdo->len_tot = 0;
  pcdo->u_flag = 0;
  pcdo->inst_type = 0;
  pcdo->user_flag = 0;
  pcdo->sz_mnem = pstr;
  pcdo->sl_mnem = slen;
  pcdo->lastval = 0;
  pcdo->mod_base = mb;
  pcdo->mod_size = ms;
  pcdo->ps_vbpdi = pdi;
  pcdo->org_cpol = 0;
  pcdo->func_qs = NULL;
  pcdo->bk_idx = 0;
  return 0;
}

/*
pcf_decode
����pcode
����ֵ:
0Ϊ�ɹ�,��0ʧ��
*/
int pcf_decode(PPDO pcdo, UINT dcFlag)
{
  UINT idx;
  UINT max;
  PBYTE pbuf;
  BYTE opc;
  BYTE lidx;      //Lead Index

  if (!pcdo) return -1;
  if (!pcdo->inp_opbuf || !pcdo->inp_count) return -2;
  if (pcdo->inp_idx > pcdo->inp_count) return -3;      //End Of Buffer
  if (pcdo->inp_idx == pcdo->inp_count) return 1;      //End Of Buffer

  idx = pcdo->inp_idx;
  max = pcdo->inp_count;
  pbuf = pcdo->inp_opbuf;
  opc = pbuf[idx];            //[o][?][?]

  pcdo->bk_idx = idx;
  pcdo->ib_std = opc;

  if (opc >= 0xFB && opc <= 0xFF)   //lead
  {
    if (++idx >= max) return -4;    //[*][o][?]
    if (opc == 0xFF && pbuf[idx] >= 0x47) return -5;

    lidx = opc - 0xFB;
    opc = pbuf[idx];
    pcdo->ib_lead = opc;

    if (PCodeLeadInst[lidx][opc].inst_len < 0)      //size == -1 ���
    {
      if (idx + 3 > max) return -6;
      USHORT vlen = *(USHORT *)(&pbuf[++idx]);

      if (vlen & 1)
      {
        pcdo->lastval |= PCEC_NOTEVEN;
        vlen &= 0xFFFE;
      }

      idx += 2;
      pcdo->len_std = 4;
      pcdo->len_tot = 4 + vlen;
      pcdo->inst_type = PCodeLeadInst[lidx][opc].inst_type;
      idx += vlen;
    }
    else
    {
      idx += PCodeLeadInst[lidx][opc].inst_len;
      pcdo->len_std = 2;
      pcdo->len_tot = PCodeLeadInst[lidx][opc].inst_len + 1;
      pcdo->inst_type = PCodeLeadInst[lidx][opc].inst_type;
    }
  }
  else
  {
    if (PCodeStdInst[opc].inst_len < 0)      //size == -1 ���
    {
      if (idx + 3 > max) return -7;
      USHORT vlen = *(USHORT *)(&pbuf[++idx]);

      if (vlen & 1)
      {
        pcdo->lastval |= PCEC_NOTEVEN;
        vlen &= 0xFFFE;
      }

      idx += 2;
      pcdo->len_std = 3;
      pcdo->len_tot = 3 + vlen;
      pcdo->inst_type = PCodeStdInst[opc].inst_type;
      idx += vlen;
    }
    else
    {
      idx += PCodeStdInst[opc].inst_len;
      pcdo->len_std = 1;
      pcdo->len_tot = PCodeStdInst[opc].inst_len;
      pcdo->inst_type = PCodeStdInst[opc].inst_type;
    }
  }

  if (idx > max)
  {
    pcdo->lastval |= PCEC_NOBYTE;
    return 2;
  }
  else if (idx == max) pcdo->lastval |= PCEC_DECEND;

  if ((dcFlag & PCDF_INCREMENTCOUNT) == 0) pcdo->inp_idx = idx;

  return 0;
}

/*
��ӡ����
*/

int pcf_print_arg(PPDO pcdo, PLONG cpool, LONG ocpool)
{
  if (pcdo->ib_std >= 0xFB) return -33;
  if (PCodeStdInst[pcdo->ib_std].text_param == NULL) return -34;
  if (pcdo->bk_idx + pcdo->len_std >= pcdo->inp_count) return -35;
  if (pcdo->len_std >= pcdo->len_tot) return -36;
  if (pcdo->bk_idx + pcdo->len_tot > pcdo->inp_count) return -37;
  if (!pcdo->ps_vbpdi || !pcdo->ps_vbpdi->pTableInfo) return -38;
  if (!cpool) return -39;

  PBYTE vbuf = &pcdo->inp_opbuf[pcdo->bk_idx + pcdo->len_std];
  PWCHAR prmt = (PWCHAR)PCodeStdInst[pcdo->ib_std].text_param;
  uint64_t ui64;
  uint32_t vidx = 0, vmax = pcdo->len_tot - pcdo->len_std, ui32;
  int32_t si32, si32tmp;
  int16_t si16;
  uint16_t ui16, ui16_1;
  WCHAR stmp[MSPC_MAX_BUFFER];

  while (*prmt)
  {
    if (*prmt != L'%')
    {
      wcsncat_s(pcdo->sz_mnem, pcdo->sl_mnem, prmt, 1);
      prmt++;
      continue;
    }

    if (*(++prmt) == 0) break;

    switch (*prmt)
    {
    case L'a':
      if (vidx + 2 > vmax) return -40;
      si32 = GetSI32FormPUI16(&vbuf[vidx]);
      MakeArg(si32, pcdo->sz_mnem, pcdo->sl_mnem);
      vidx += 2;
      break;
    case L'c':
      if (vidx + 2 > vmax) return -41;
      ui16 = GetUI16FormP16(&vbuf[vidx]);
      si32 = ui16 * 4 + *cpool;
      ui32 = GetUI32FormP32((void *)si32);
      MakeAddrToVB(pcdo, ui32);
      vidx += 2;
      break;
    case L'e':
      if (vidx + 4 > vmax) return -42;
      ui16 = GetUI16FormP16(&vbuf[vidx]);
      si32 = ui16 * 4 + *cpool;
      si32 = GetSI32FormP32((void *)si32);
      ui32 += GetUI32FormPSI16(&vbuf[vidx + 2]);
      MakeAddr(pcdo, ui32);
      vidx += 4;
      break;
    case L'x':   //External Api
      if (vidx + 2 > vmax) return -43;
      ui16 = GetSI16FormP16(&vbuf[vidx]);
      si32 = ui16 * 4 + *cpool;
      ui32 = GetUI32FormP32((void *)si32);
      ReturnApiCall(pcdo, ui32);
      vidx += 2;
      break;
    case L's':
      if (vidx + 2 > vmax) return -44;
      ui16 = GetUI16FormP16(&vbuf[vidx]);
      si32 = ui16 * 4 + *cpool;
      ui32 = GetUI32FormP32((void *)si32);

      swprintf_s(stmp, MSPC_MAX_BUFFER, L"v_%08X", ui32);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);

      if (pcdo->sz_note && pcdo->sl_note)
      {
        wcscpy_s(pcdo->sz_note, pcdo->sl_note, L" \"");
        swprintf_s(stmp, MSPC_MAX_BUFFER, L"%s", ui32);
        wcscat_s(stmp, MSPC_MAX_BUFFER, L"\" ");
        wcscat_s(pcdo->sz_note, pcdo->sl_note, stmp);
      }

      vidx += 2;
      break;
    case L'l':
      if (vidx + 2 > vmax) return -45;
      si32 = (int)pcdo->inp_opbuf + GetSI32FormPSI16(&vbuf[vidx]);
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"loc_%08X", si32);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      vidx += 2;
      break;
    case L'1':
      if (vidx + 1 > vmax) return -46;
      ui32 = (uint32_t)*(uint8_t *)&vbuf[vidx];
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"%02X", ui32);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      vidx++;
      break;
    case L'2':
      if (vidx + 2 > vmax) return -47;
      ui32 = (uint32_t)*(uint16_t *)&vbuf[vidx];
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"%04X", ui32);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      vidx += 2;
      break;
    case L'4':
      if (vidx + 4 > vmax) return -48;
      ui32 = *(uint32_t *)&vbuf[vidx];
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"%08X", ui32);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      vidx += 4;
      break;
    case L'8':
      if (vidx + 8 > vmax) return -49;
      ui64 = *(uint64_t *)&vbuf[vidx];
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"%016I64X", ui64);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      vidx += 8;
      break;
    case L't':
      if (vidx + 2 > vmax) return -50;
      ui16 = GetUI16FormP16(&vbuf[vidx]);    //FIdx  ?
      ui32 = ui16 * 4 + ocpool;
      ui32 = *(uint32_t *)ui32;
      swprintf_s(stmp, MSPC_MAX_BUFFER, L"xxx_%08X", ui32);
      wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
      *cpool = ui32;
      vidx += 2;
      break;
    case L'v':
      if (vidx + 4 > vmax) return -51;
      ui16_1 = GetUI16FormP16(&vbuf[vidx]);
      vidx += 2;
      ui16 = GetUI16FormP16(&vbuf[vidx]);
      si32tmp = GetSI32FormP32((void *)(ui16 * 4 + *cpool));
      GetPropertyText(*(GUID *)si32tmp, ui16_1, pcdo->sz_mnem, pcdo->sl_mnem, pcdo->sz_note, pcdo->sl_note);
      vidx += 2;
      break;
    default:
      break;
    }
    prmt++;
  }

  return 0;
}

/*
P-Code �����
*/
int pcf_disassemble(PPDO pcdo)
{
  static LONG bkcpol;
  static LONG scpol;

  int iret;
  size_t bval;
  PLONG pcp;
  BYTE cop;       //current op
  BYTE opidx;

  if (!pcdo) return -65;
  if (!pcdo->inp_opbuf || !pcdo->inp_count) return -66;
  if (!pcdo->sz_mnem || pcdo->sl_mnem == 0) return -67;
  if (pcdo->inp_idx > pcdo->inp_count) return -68;      //End Of Buffer
  if (pcdo->inp_idx == pcdo->inp_count) return 1;

  iret = pcf_decode(pcdo, 0);
  if (iret != 0) return iret;

  pcdo->sz_mnem[0] = 0;
  if (pcdo->sl_note && pcdo->sz_note) pcdo->sz_note[0] = 0;

  if (pcdo->bl_init)
  {
    bkcpol = pcdo->ps_vbpdi->pTableInfo->ConstPool;
    scpol = pcdo->ps_vbpdi->pTableInfo->ConstPool;
    pcdo->bl_init = FALSE;
  }

  cop = pcdo->ib_std;
  if (cop < 0xFB)   //��׼ָ��
  {
    if (mbstowcs_s(&bval, pcdo->sz_mnem, pcdo->sl_mnem, PCodeStdInst[cop].text_inst, _TRUNCATE))
      return -70;

    if (PCodeStdInst[cop].text_param)
    {
      if ((pcdo->inst_type & 0xFFFF) == PCT_IDX)
        pcp = &scpol;
      else
        pcp = &bkcpol;

      iret = pcf_print_arg(pcdo, pcp, pcdo->ps_vbpdi->pTableInfo->ConstPool);
      if (iret != 0) return iret;
    }
  }
  else
  {
    WCHAR stmp[128];

    opidx = cop - 0xFB;
    cop = pcdo->ib_lead;

    swprintf_s(pcdo->sz_mnem, pcdo->sl_mnem, L"#%1u:", (UINT)opidx);

    if (mbstowcs_s(&bval, stmp, 128, PCodeLeadInst[opidx][cop].text_inst, _TRUNCATE))
      return -71;

    wcscat_s(pcdo->sz_mnem, pcdo->sl_mnem, stmp);
  }

  if ((pcdo->lastval & PCEC_DECEND) == PCEC_DECEND) return 1;
  if ((pcdo->inst_type & PCF_ENDPROC) == PCF_ENDPROC) return 1;

  return 0;
}

