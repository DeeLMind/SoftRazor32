#pragma once

#include <stdint.h>
#include <Windows.h>
#include <tchar.h>

#include "vbstruct.h"

/*
Reference From Semi VB Decompiler
Thank: vbgamer45
http://www.vbforums.com/member.php?51546-vbgamer45
*/

/* pcode type 0x00 - 0xFF */
#define PCT_STD                   1
#define PCT_IDX                   2
#define PCT_CLEARMEMORY           3
#define PCT_ONESTRING             4
#define PCT_RETONEVAR             5
#define PCT_ADDARGTOATACK         6
#define PCT_NONE                  99

/* pcode type1 0x0100 - 0xFF00 */
#define PCF_DBG                   0x0100

/* pcode flag 0x00010000 - 0xFFFF0000 */
#define PCF_ENDPROC               0x00010000
#define PCF_WARNING               0x00020000
#define PCF_INVALID               0x00040000

/* pcode decode flag */
#define PCDF_INCREMENTCOUNT       0x00000001U

typedef int (WINAPI * func_qsymbol)(int qaddr, wchar_t * iText, size_t maxc);

typedef struct _VB_PCODE_INSTRUCTIONSET
{
  LPCCH                               text_inst;
  LPCTCH                              text_param;
  UINT                                inst_type;
  signed int                          inst_len;
} VB_PCODE_INSTRUCTIONSET, VBPCINSET, *PVBPCINSET;

typedef struct _PCODE_DECODE_OBJECT
{
  /* ���뻺�� */
  PBYTE                       inp_opbuf;          //set in
  /* ��ǰλ�� */
  UINT                        inp_idx;            //in
  /* �����С */
  UINT                        inp_count;          //set in
  UINT                        len_std;            //out ָ��� + ���� = ��׼����
  UINT                        len_tot;            //out ��׼���� + ��� = �ܳ���
  UINT                        u_flag;             //out
  UINT                        inst_type;          //out
  UINT                        user_flag;          //out
  LONG                        org_cpol;           //ԭConst Pool
  PWCHAR                      sz_mnem;            //set out  Mnemonic
  UINT                        sl_mnem;            //set in
  PWCHAR                      sz_note;            //set out
  UINT                        sl_note;            //set in
  UINT                        mod_base;           //set in
  UINT                        mod_size;           //set in
  PVBPDI                      ps_vbpdi;           //set in
  func_qsymbol                func_qs;            //query symbol function
  BOOL                        bl_init;
  UINT                        lastval;            //out
  UINT                        bk_idx;
  BYTE                        ib_std;
  BYTE                        ib_lead;
} PCODE_DECODE_OBJECT, PDO, *PPDO;
